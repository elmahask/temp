import React, { useEffect, useState } from 'react';
import axiosInstance from '../axiosConfig';
// import './App.css'; // Ensure you import your CSS file

const Employee = () => {
    const [employees, setEmployees] = useState([]);
    const [name, setName] = useState('');
    const [position, setPosition] = useState('');
    const [salary, setSalary] = useState('');
    const [editId, setEditId] = useState(null);

    useEffect(() => {
        fetchEmployees();
    }, []);

    const fetchEmployees = async () => {
        const response = await axiosInstance.get('/employees');
        setEmployees(response.data);
    };

    const addOrUpdateEmployee = async () => {
        const employeeData = { name, position, salary: parseFloat(salary) };
        
        if (editId) {
            await axiosInstance.put(`/employees/${editId}`, employeeData);
        } else {
            console.log(employeeData)
            await axiosInstance.post('/employees', employeeData);
        }

        resetForm();
        fetchEmployees();
    };

    const deleteEmployee = async (id) => {
        await axiosInstance.delete(`/employees/${id}`);
        fetchEmployees();
    };

    const editEmployee = (employee) => {
        setEditId(employee.id);
        setName(employee.name);
        setPosition(employee.position);
        setSalary(employee.salary);
    };

    const resetForm = () => {
        setEditId(null);
        setName('');
        setPosition('');
        setSalary('');
    };

    return (
        <div className="employee-container">
            <h1>Employee Management</h1>
            <input className="input-field" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} />
            <input className="input-field" placeholder="Position" value={position} onChange={(e) => setPosition(e.target.value)} />
            <input className="input-field" placeholder="Salary" type="number" value={salary} onChange={(e) => setSalary(e.target.value)} />
            <button className="btn btn-primary" onClick={addOrUpdateEmployee}>
                {editId ? 'Update Employee' : 'Add Employee'}
            </button>

            <table className="employee-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Position</th>
                        <th>Salary</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {employees.map(emp => (
                        <tr key={emp.id}>
                            <td>{emp.id}</td>
                            <td>{emp.name}</td>
                            <td>{emp.position}</td>
                            <td>${emp.salary.toFixed(2)}</td>
                            <td>
                                <button className="btn btn-edit" onClick={() => editEmployee(emp)}>Edit</button>
                                <button className="btn btn-delete" onClick={() => deleteEmployee(emp.id)}>Delete</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default Employee;
