import './App.css';
import Employee from './employee/Employee';

function App() {
  return (
    <div className="App">
      <Employee />
    </div>
  );
}

export default App;
