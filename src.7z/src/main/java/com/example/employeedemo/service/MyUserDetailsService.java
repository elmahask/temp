package com.example.employeedemo.service;

import com.example.employeedemo.model.Users;
import com.example.employeedemo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;

@Service
public class MyUserDetailsService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        //Users users = userRepository.findByUsername(username);
        Users users = new Users();
        users.setId(1l);
        users.setUsername("wael");
        users.setPassword("P@ssw0rd");
        if (users == null) {
            throw new UsernameNotFoundException("Users not found");
        }
//        return new User(users.getUsername(), users.getPassword(), Collections.emptyList());

                return  User.withUsername(users.getUsername()).password("{noop}" + users.getPassword()).authorities(new ArrayList<>()) // Provide authorities if needed
                        .build();
    }
}
