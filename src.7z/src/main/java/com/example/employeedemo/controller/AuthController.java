package com.example.employeedemo.controller;

import com.example.employeedemo.dto.AuthRequest;
import com.example.employeedemo.model.Users;
import com.example.employeedemo.repository.UserRepository;
import com.example.employeedemo.service.MyUserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin("*")
public class AuthController {
//    @Autowired
//    private AuthenticationManager authenticationManager;

//    @Autowired
//    private MyUserDetailsService userDetailsService;

    @Autowired
    private UserRepository userRepository;

    /*@Autowired
    private PasswordEncoder passwordEncoder;*/

    /*@PostMapping("/login")
    public String login(@RequestBody AuthRequest authRequest) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword())
            );
            if (authentication.isAuthenticated()) {
                return "Login successful!";
            } else {
                return "Invalid credentials!";
            }
        } catch (AuthenticationException e) {
            return "Invalid credentials!";
        }
    }*/

    @GetMapping("/login")
    public ResponseEntity securedApi(@RequestHeader HttpHeaders headers) {
        if (headers.containsKey(HttpHeaders.AUTHORIZATION)) {
            String authorizationHeader = headers.getFirst(HttpHeaders.AUTHORIZATION);
            System.out.println(authorizationHeader);
            if (authorizationHeader.startsWith("Basic ")) {
//                Authentication authentication = authenticationManager.authenticate(
//                        new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword())
//                );
                return new ResponseEntity<>("Authentication passed", HttpStatus.OK);
            }
        }
        return new ResponseEntity("Unauthorized", HttpStatus.UNAUTHORIZED);
    }

    @PostMapping("/signup")
    public String signup(@RequestBody AuthRequest authRequest) {
        if (userRepository.findByUsername(authRequest.getUsername()) != null) {
            return "Username already taken!";
        }

        Users users = new Users();
        users.setUsername(authRequest.getUsername());
        //users.setPassword(passwordEncoder.encode(authRequest.getPassword()));
        users.setPassword(authRequest.getPassword());
        userRepository.save(users);

        return "Users registered successfully!";
    }
}